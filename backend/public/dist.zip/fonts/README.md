Place your Lastica font files here.

Required filenames:

- Lastica.woff2 (recommended)
- Lastica.ttf (fallback)

The app loads from `/fonts/Lastica.woff2` and `/fonts/Lastica.ttf`.
