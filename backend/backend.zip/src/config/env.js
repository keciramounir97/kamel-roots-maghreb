const path = require("path");
const dotenv = require("dotenv");

dotenv.config({ path: path.join(__dirname, "..", "..", ".env") });

const buildDatabaseUrl = () => {
  const host = process.env.DB_HOST;
  const port = process.env.DB_PORT || 3306;
  const name = process.env.DB_NAME;
  const user = process.env.DB_USER;
  const pass = process.env.DB_PASSWORD;
  if (!host || !name || !user || pass === undefined) return null;
  const encodedUser = encodeURIComponent(user);
  const encodedPass = encodeURIComponent(pass);
  return `mysql://${encodedUser}:${encodedPass}@${host}:${port}/${name}`;
};

// Force DATABASE_URL to align with DB_* if provided
(() => {
  const url = buildDatabaseUrl();
  if (url) {
    process.env.DATABASE_URL = url;
  }
})();

const DEFAULT_CORS_ORIGINS = [
  "http://localhost:5173",
  "http://localhost:4173",
  "http://127.0.0.1:5173",
  "http://127.0.0.1:4173",
  "http://localhost:5000",
  "https://rootsmaghreb.com",
  "https://www.rootsmaghreb.com",
];

const stripQuotes = (value) => String(value || "").replace(/^["']|["']$/g, "");

const normalizeOrigin = (origin) =>
  stripQuotes(String(origin || "").trim()).replace(/\/$/, "");

const RAW_ALLOWED = process.env.CORS_ORIGIN
  ? process.env.CORS_ORIGIN.split(",")
  : DEFAULT_CORS_ORIGINS;

const allowedOrigins = RAW_ALLOWED.map(normalizeOrigin).filter(Boolean);

const isAllowedOrigin = (origin) => {
  if (!origin) return true;
  const normalized = normalizeOrigin(origin);
  if (!normalized) return false;
  return allowedOrigins.includes(normalized);
};

const parseDbName = () => {
  if (process.env.DB_NAME) return process.env.DB_NAME;
  try {
    const parsed = new URL(process.env.DATABASE_URL || "");
    return parsed.pathname.replace(/^\//, "") || null;
  } catch {
    return null;
  }
};

const DB_NAME = parseDbName();
let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  JWT_SECRET = process.env.JWT_FALLBACK || "change-me-in-prod";
  console.warn(
    "Missing JWT_SECRET in backend/.env. Using fallback secret — set JWT_SECRET in production."
  );
}

module.exports = {
  allowedOrigins,
  isAllowedOrigin,
  DB_NAME,
  JWT_SECRET,
  PORT: Number(process.env.PORT) || 5000,
  SESSION_TTL_SECONDS:
    Number(process.env.SESSION_TTL_SECONDS) ||
    Number(process.env.JWT_EXPIRES_IN) ||
    60 * 60 * 24 * 30,
  RESET_TTL_SECONDS: Number(process.env.RESET_CODE_TTL) || 900,
};
