const app = require("./server");

if (typeof app.initializeServer !== "function") {
  throw new Error("Server initializer not available");
}

app.initializeServer();
