const express = require("express");
const path = require("path");
const fs = require("fs");
const cors = require("cors");

// Environment configuration
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;
const NODE_ENV = process.env.NODE_ENV || "development";
const isProduction = NODE_ENV === "production";
const isTest = NODE_ENV === "test";
const FRONTEND_DIST_DIR = process.env.FRONTEND_DIST_DIR
  ? path.resolve(process.env.FRONTEND_DIST_DIR)
  : path.join(__dirname, "../frontend/dist");
const FRONTEND_INDEX = path.join(FRONTEND_DIST_DIR, "index.html");

console.log(`🚀 Starting server in ${NODE_ENV} mode...`);

// Import configuration and utilities
const { isAllowedOrigin } = require("./src/config/env");
const { UPLOADS_DIR } = require("./src/utils/files");
const { transporter } = require("./src/lib/mailer");
const { prisma } = require("./src/lib/prisma");
const { markDbDown } = require("./src/utils/dbState");
const { ensureSchema } = require("./src/services/schemaService");
const {
  ensureDefaultRoles,
  ensureSeedAdminUser,
} = require("./src/services/seedService");

// Import routes
const authRoutes = require("./src/routes/authRoutes");
const userRoutes = require("./src/routes/userRoutes");
const settingsRoutes = require("./src/routes/settingsRoutes");
const statsRoutes = require("./src/routes/statsRoutes");
const activityRoutes = require("./src/routes/activityRoutes");
const bookRoutes = require("./src/routes/bookRoutes");
const treeRoutes = require("./src/routes/treeRoutes");
const searchRoutes = require("./src/routes/searchRoutes");
const contactRoutes = require("./src/routes/contactRoutes");
const personRoutes = require("./src/routes/personRoutes");
const healthRoutes = require("./src/routes/healthRoutes");
const roleRoutes = require("./src/routes/roleRoutes");
const galleryRoutes = require("./src/routes/galleryRoutes");
const gedcomRoutes = require("./src/routes/gedcomRoutes");
const newsletterRoutes = require("./src/routes/newsletterRoutes");
const diagnosticsRoutes = require("./src/routes/diagnosticsRoutes");
const { uploadErrorHandler } = require("./src/middlewares/uploadErrorHandler");
const { getDatabaseErrorResponse } = require("./src/utils/prismaErrors");

// ===================
// Middleware Setup
// ===================

// CORS configuration (reflect caller + explicit headers for preflight)
// CORS configuration
const corsOptions = {
  origin(origin, callback) {
    // Allow requests with no origin (mobile apps, Postman, etc.)
    if (!origin) return callback(null, true);

    if (isAllowedOrigin(origin)) {
      return callback(null, true);
    }

    console.warn(`Blocked CORS request from: ${origin}`);
    return callback(null, false);
  },
  credentials: true,
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
  optionsSuccessStatus: 204,
};

app.use(cors(corsOptions));
app.options(/.*/, cors(corsOptions));

// Body parsing
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Static files
app.use("/uploads", express.static(UPLOADS_DIR));

// Trust proxy (important for production behind reverse proxy)
if (isProduction) {
  app.set("trust proxy", 1);
}

// Request logging (simple)
app.use((req, res, next) => {
  console.log(`${req.method} ${req.path}`);
  next();
});

// ===================
// API Routes
// ===================

// Base API endpoint (helps hosting health checks)
app.get("/api", (req, res) => {
  res.json({ status: "ok" });
});

app.use("/api/auth", authRoutes);
app.use("/api", userRoutes);
app.use("/api", settingsRoutes);
app.use("/api", statsRoutes);
app.use("/api", activityRoutes);
app.use("/api", bookRoutes);
app.use("/api", treeRoutes);
app.use("/api", searchRoutes);
app.use("/api", contactRoutes);
app.use("/api", personRoutes);
app.use("/api", healthRoutes);
app.use("/api", roleRoutes);
app.use("/api", galleryRoutes);
app.use("/api", gedcomRoutes);
app.use("/api", newsletterRoutes);
app.use("/api", diagnosticsRoutes);

// Upload error handler (multer/file parsing)
app.use(uploadErrorHandler);

// Health check endpoint
app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    environment: NODE_ENV,
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

// Root endpoint (simple 200 for platform health checks)
app.get("/", (req, res) => {
  // If we are in production and have a frontend build, serve it
  if (isProduction && fs.existsSync(FRONTEND_INDEX)) {
    return res.sendFile(FRONTEND_INDEX);
  }
  res.status(200).send("OK - Backend is running");
});

// Serve frontend static files in production
if (isProduction) {
  if (fs.existsSync(FRONTEND_DIST_DIR)) {
    // Serve static assets with long cache policy
    app.use(
      "/assets",
      express.static(path.join(FRONTEND_DIST_DIR, "assets"), {
        maxAge: "1y",
        immutable: true,
        fallthrough: false, // Do not fall through to SPA catch-all if asset missing
      })
    );

    // Serve other static files (favicon, manifest, etc)
    app.use(express.static(FRONTEND_DIST_DIR));

    // Handle SPA routing - return index.html for any unknown route NOT starting with /api
    app.get(/^\/(?!api(?:\/|$)|uploads(?:\/|$)).*/, (req, res) => {
      res.sendFile(FRONTEND_INDEX);
    });
  }
}

// ===================
// Error Handling
// ===================

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: "Not Found",
    message: `Cannot ${req.method} ${req.path}`,
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error("❌ Error:", err);

  const dbError = getDatabaseErrorResponse(err);
  if (dbError) {
    return res.status(dbError.status).json({
      error: "ServiceUnavailable",
      message: dbError.message,
    });
  }

  // Don't leak error details in production
  const message = isProduction ? "Internal Server Error" : err.message;
  const stack = isProduction ? undefined : err.stack;

  res.status(err.status || 500).json({
    error: err.name || "ServerError",
    message,
    ...(stack && { stack }),
  });
});

// ===================
// Initialization
// ===================

async function initializeServer() {
  try {
    let dbReady = false;

    // Test database connection
    if (!isTest) {
      try {
        await prisma.$queryRaw`SELECT 1`;
        dbReady = true;
        console.log("Database connected");
      } catch (err) {
        console.error("Database connection failed:", err.message);
        markDbDown(err);
      }
    }

    // Run schema and seed operations
    if (dbReady && !isTest) {
      try {
        console.log("Ensuring database schema...");
        await ensureSchema();
        console.log("Database schema ensured");
      } catch (err) {
        console.error("Database schema ensure failed:", err.message);
      }

      if (process.env.SKIP_MAINTENANCE !== "true") {
        try {
          console.log("Running database maintenance...");
          await ensureDefaultRoles();
          await ensureSeedAdminUser();
          console.log("Database maintenance complete");
        } catch (err) {
          console.error("Database maintenance failed:", err.message);
        }
      }
    } else if (!dbReady && !isTest) {
      console.warn("Database unavailable, skipping maintenance");
    }

    // Test SMTP connection
    if (!isTest && process.env.SMTP_HOST) {
      transporter.verify((err) => {
        if (err) {
          console.error("❌ SMTP Error:", err.message);
        } else {
          console.log("✅ SMTP ready");
        }
      });
    }

    // Start server
    const server = app.listen(PORT, "0.0.0.0", () => {
      console.log(`
╔═══════════════════════════════════════════╗
║   🌍 Roots Maghreb Server Running        ║
║   📍 http://localhost:${PORT.toString().padEnd(20)}║
║   🔧 Environment: ${NODE_ENV.padEnd(19)}║
╚═══════════════════════════════════════════╝
      `);
    });

    // Graceful shutdown
    const gracefulShutdown = async (signal) => {
      console.log(`\n⚠️  Received ${signal}, shutting down gracefully...`);

      server.close(async () => {
        console.log("🔒 HTTP server closed");

        try {
          await prisma.$disconnect();
          console.log("🔒 Database connection closed");
          process.exit(0);
        } catch (err) {
          console.error("❌ Error during shutdown:", err);
          process.exit(1);
        }
      });

      // Force shutdown after 10 seconds
      setTimeout(() => {
        console.error("⏰ Forcing shutdown after timeout");
        process.exit(1);
      }, 10000);
    };

    // Handle shutdown signals
    process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
    process.on("SIGINT", () => gracefulShutdown("SIGINT"));

    // Handle uncaught errors
    process.on("uncaughtException", (err) => {
      console.error("💥 Uncaught Exception:", err);
      if (isProduction) {
        gracefulShutdown("UNCAUGHT_EXCEPTION");
      }
    });

    process.on("unhandledRejection", (reason, promise) => {
      console.error("💥 Unhandled Rejection at:", promise, "reason:", reason);
      if (isProduction) {
        gracefulShutdown("UNHANDLED_REJECTION");
      }
    });
  } catch (error) {
    console.error("❌ Failed to initialize server:", error);
    process.exit(1);
  }
}

// Start the server only if run directly
if (require.main === module) {
  initializeServer();
}

app.initializeServer = initializeServer;
module.exports = app; // Export for testing
